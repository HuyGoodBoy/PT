class Bird:
    def __init__(self, xType, xRate, xWing):
        self.type = xType
        self.rate = xRate
        self.wing = xWing

class BSTreeNode:
    def __init__(self, key, bird):
        self.key = key
        self.bird = bird
        self.left = None
        self.right = None

class BSTree:
    def __init__(self):
        self.root = None

    def f0(self):
        return "HE180002"

    def insert(self, xType, xRate, xWing):
        if xType[0] == 'B' or xRate > 10:
            return

        new_bird = Bird(xType, xRate, xWing)
        if not self.root:
            self.root = BSTreeNode(xRate, new_bird)
        else:
            self._insert(self.root, xRate, new_bird)

    def _insert(self, node, key, bird):
        if key < node.key:
            if node.left is None:
                node.left = BSTreeNode(key, bird)
            else:
                self._insert(node.left, key, bird)
        elif key > node.key:
            if node.right is None:
                node.right = BSTreeNode(key, bird)
            else:
                self._insert(node.right, key, bird)

    def f1(self):
        self._inorder(self.root)

    def _inorder(self, node):
        if node:
            self._inorder(node.left)
            print(f'({node.bird.type},{node.bird.rate},{node.bird.wing})', end=' ')
            self._inorder(node.right)

    def f2(self):
        self._preorder_wing_range(self.root, 4, 10)

    def _preorder_wing_range(self, node, min_wing, max_wing):
        if node:
            if min_wing <= node.bird.wing <= max_wing:
                print(f'({node.bird.type},{node.bird.rate},{node.bird.wing})', end=' ')
            self._preorder_wing_range(node.left, min_wing, max_wing)
            self._preorder_wing_range(node.right, min_wing, max_wing)

    def f3(self):
        self._bfs_odd_position()

    def _bfs_odd_position(self):
        if not self.root:
            return

        queue = [self.root]
        odd_position = True

        while queue:
            node = queue.pop(0)
            if odd_position:
                print(f'({node.bird.type},{node.bird.rate},{node.bird.wing})', end=' ')
            odd_position = not odd_position

            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)

    def f4(self):
        self._postorder_wing_rate_range(self.root, 4, float('inf'), 6)

    def _postorder_wing_rate_range(self, node, max_wing, min_rate, max_rate):
        if node:
            self._postorder_wing_rate_range(node.left, max_wing, min_rate, max_rate)
            self._postorder_wing_rate_range(node.right, max_wing, min_rate, max_rate)
            if node.bird.wing <= max_wing and node.bird.rate > min_rate:
                print(f'({node.bird.type},{node.bird.rate},{node.bird.wing})', end=' ')


# Example usage
bst = BSTree()
bst.insert('A', 5, 9)
bst.insert('E', 2, 5)
bst.insert('D', 8, 6)
bst.insert('F', -6, 7)
bst.insert('X', 4, 5)
bst.insert('Y', 6, -7)

print("MSV:", bst.f0())
print("f1:")
bst.f1()

print("\nf2:")
bst.f2()

print("\nf3:")
bst.f3()

print("\nf4:")
bst.f4()
